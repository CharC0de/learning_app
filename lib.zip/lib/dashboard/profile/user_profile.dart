import 'dart:async';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../main.dart';

class UserProfile extends StatefulWidget {
  const UserProfile({super.key});
  @override
  State<UserProfile> createState() => _UserProfile();
}

class _UserProfile extends State<UserProfile> {
  @override
  initState() {
    super.initState();
    getUserData();
  }

  final userData = {
    "uName": "",
    "fName": "",
    "lName": "",
    "contact": "",
    "pfp": "",
    "type": "",
  };
  StreamSubscription? userStream;
  final storeRef = FirebaseStorage.instance.ref();
  final dbRef = FirebaseDatabase.instanceFor(
          app: Firebase.app(),
          databaseURL:
              "https://learning-app-c8a25-default-rtdb.asia-southeast1.firebasedatabase.app/")
      .ref();
  final userRef = FirebaseAuth.instance;
  Image? pfp;
  getUserData() {
    userStream = dbRef
        .child('users/${userRef.currentUser!.uid}/')
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = (event.snapshot.value as Map<dynamic, dynamic>)
            .cast<String, dynamic>();
        setState(() {
          userData["uName"] = resData["uName"];
          userData["fName"] = resData["fName"];
          userData["lName"] = resData["lName"];
          userData["contact"] = resData["contact"];
          userData["pfp"] = resData["pfp"];
          userData["type"] = resData["type"];
        });
      }
    });
  }

  Future<Widget> getAll() async {
    try {
      debugPrint(userRef.currentUser!.uid);
      final ref = FirebaseStorage.instance
          .ref()
          .child("${userRef.currentUser!.uid}/${userData["pfp"]}");
      final url = await ref.getDownloadURL();
      return Column(
        children: [
          CircleAvatar(
            radius: 100,
            backgroundImage: NetworkImage(url),
          ),
          Card(
              margin: const EdgeInsets.all(10),
              child: Container(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Username: ${userData["uName"]!}"),
                        Text("Email: ${userRef.currentUser!.email}"),
                        Text("First name: ${userData["fName"]!}"),
                        Text("Last name: ${userData["lName"]!}"),
                        Text("Contact #: ${userData["contact"]!}"),
                        Text("Type: ${userData["type"]!}"),
                      ])))
        ],
      );
    } catch (e) {
      debugPrint('Error loading image from Firebase Storage: $e');
      debugPrint('>>${userRef.currentUser!.uid}/${userData["pfp"]}');
      // Handle the error or return a placeholder image.
      return const Icon(Icons.account_circle,
          size: 200, color: Colors.grey); // You can use a placeholder image.
    }
  }

  Container iconContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile"),
        actions: [
          GestureDetector(
            onTap: () {
              FirebaseAuth.instance.signOut();
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => const Login()));
            },
            child: iconContainer(const Icon(Icons.logout_outlined)),
          )
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
            child: FutureBuilder<Widget>(
          future: getAll(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator(); // Display a loading indicator while fetching the image.
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return snapshot.data ?? const Text('Image not found');
            }
          },
        )),
      ),
    );
  }

  @override
  void deactivate() {
    userStream!.cancel();
    super.deactivate();
  }
}
