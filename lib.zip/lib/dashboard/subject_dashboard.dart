import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';
import '../main.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'profile/user_profile.dart';
import '../register/create_subs/create_sub_act.dart';

class SubjectDashboard extends StatefulWidget {
  const SubjectDashboard({super.key, required this.details, required this.id});
  final Map<dynamic, dynamic> details;
  final String id;
  @override
  State<SubjectDashboard> createState() => _SubjectDashboardState();
}

class _SubjectDashboardState extends State<SubjectDashboard> {
  bool deleteMode = false;
  List<String> subjectIds = [];
  @override
  void initState() {
    getUserData();
    getActs();
    super.initState();
  }

  Container buttonStyle(Widget widget) {
    return Container(padding: const EdgeInsets.all(7), child: widget);
  }

  void _launchURL(String url) async {
    // Replace with the URL you want to open
    if (await canLaunchUrlString(url)) {
      launchUrlString(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  StreamSubscription? userStream;
  StreamSubscription? subjStream;
  StreamSubscription? actStream;
  final storeRef = FirebaseStorage.instance.ref();
  final dbRef = FirebaseDatabase.instanceFor(
          app: Firebase.app(),
          databaseURL:
              "https://learning-app-c8a25-default-rtdb.asia-southeast1.firebasedatabase.app/")
      .ref();
  final userRef = FirebaseAuth.instance;
  String pfp = "";
  dynamic actData = {};

  /*getSubs() {
    subjStream = dbRef
        .child('subjects/')
        .orderByChild("teacherId")
        .equalTo(userRef.currentUser!.uid)
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = Map<dynamic, dynamic>.from(
            event.snapshot.value as Map<dynamic, dynamic>);

        setState(() {
          actData = resData;
        });
        debugPrint("actData");
      } else {
        debugPrint("No data");
      }
    });
  }*/
  getActs() {
    actStream = dbRef
        .child('subject_acts/')
        .orderByChild("subjectId")
        .equalTo(widget.id)
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = Map<dynamic, dynamic>.from(
            event.snapshot.value as Map<dynamic, dynamic>);
        debugPrint(resData.toString());
        setState(() {
          actData = resData;
        });
      } else {
        debugPrint("No data");
      }
    });
  }

  getUserData() {
    userStream = dbRef
        .child('users/${userRef.currentUser!.uid}/')
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = (event.snapshot.value as Map<dynamic, dynamic>)
            .cast<String, dynamic>();
        setState(() {
          pfp = resData["pfp"];
        });
      }
    });
  }

  Container iconContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: child,
    );
  }

  Container detailValue(String type, String time, context) {
    IconData? icon;
    switch (type) {
      case "Start":
        type += " time";
        icon = Icons.access_time;
      case "End":
        type += " time";
        icon = Icons.access_time_filled;
      default:
        icon = Icons.calendar_month;
        break;
    }

    return Container(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        child: Row(
          children: [
            Padding(
                padding: const EdgeInsets.only(right: 5),
                child: Icon(
                  icon,
                  color: Theme.of(context).colorScheme.primary,
                )),
            Row(
              children: [
                Text.rich(TextSpan(children: [
                  TextSpan(
                    text: '$type: ',
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 12),
                  ),
                  TextSpan(text: time)
                ]))
              ],
            )
          ],
        ));
  }

  Container textValue(String type, String time, context) {
    IconData? icon;
    return Container(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        child: Row(
          children: [
            Padding(
                padding: const EdgeInsets.only(right: 5),
                child: Icon(
                  icon,
                  color: Theme.of(context).colorScheme.primary,
                )),
            Row(
              children: [
                Text.rich(TextSpan(children: [
                  TextSpan(
                    text: '$type: ',
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 12),
                  ),
                  TextSpan(text: time)
                ]))
              ],
            )
          ],
        ));
  }

  Expanded subjectInfo(
    BuildContext context, {
    String? title,
    String? desc,
    String? start,
    String? end,
    String? meet1,
    String? meet2,
  }) {
    return Expanded(
        child: Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                vertical: 5,
                horizontal: 10,
              ),
              child: Text(
                title!,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 30,
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                vertical: 5,
                horizontal: 10,
              ),
              child: Text(
                desc!,
              ),
            ),
            Wrap(
              direction: Axis.horizontal,
              children: [
                detailValue("Start", start!, context),
                detailValue("End", end!, context),
                detailValue(
                  "Meeting Days",
                  "$meet1 and $meet2",
                  context,
                )
              ],
            ),
          ],
        ),
      ),
    ));
  }

  Expanded assignButton(
    BuildContext context, {
    String? id,
    String? title,
    String? desc,
    String? deadline,
    String? type,
  }) {
    return Expanded(
      child: TextButton(
        style: ButtonStyle(
          padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
            const EdgeInsets.all(5),
          ),
        ),
        onPressed: () {
          debugPrint("$id $type");
        },
        child: Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 5,
                  horizontal: 10,
                ),
                child: const Text(
                  'Assignment',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 20,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 5,
                  horizontal: 10,
                ),
                child: Text(
                  title!,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.all(5),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: Text(desc!),
                  )),
              detailValue("Deadline", deadline!, context),
            ],
          ),
        ),
      ),
    );
  }

  Card announcement(
    BuildContext context, {
    String? date,
    String? desc,
    String? id,
    dynamic list,
  }) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            child: Text(
              DateFormat('yyyy-MM-dd HH:mm:ss').format(
                DateTime.fromMicrosecondsSinceEpoch(
                  int.parse(
                        RegExp(r'seconds=(\d+), nanoseconds=(\d+)')
                                .firstMatch(date ??
                                    "Timestamp(seconds=0, nanoseconds=0)")!
                                .group(1)! +
                            RegExp(r'seconds=(\d+), nanoseconds=(\d+)')
                                .firstMatch(date ??
                                    "Timestamp(seconds=0, nanoseconds=0)")!
                                .group(2)!,
                      ) ~/
                      1000,
                ),
              ),
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(5),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
              child: Text(desc ?? ""),
            ),
          ),
          if (list != null)
            Visibility(
              visible: list.isNotEmpty,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 5),
                child: Column(
                  children: [
                    const Text(
                      'Attachments:',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    for (final file in list)
                      TextButton(
                        onPressed: () async {
                          final url = await storeRef
                              .child("announcements/$id/$file")
                              .getDownloadURL();
                          _launchURL(url);
                        },
                        child: Text(
                          file,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<Widget> setPfp() async {
    if (pfp.isNotEmpty) {
      debugPrint(userRef.currentUser!.uid);
      final ref = FirebaseStorage.instance
          .ref()
          .child("${userRef.currentUser!.uid}/$pfp");
      final url = await ref.getDownloadURL();
      return SizedBox(
        width: 35,
        height: 35,
        child: CircleAvatar(
          radius: 100,
          backgroundImage: NetworkImage(url),
        ),
      );
    } else {
      debugPrint('noPfp');

      return const Icon(
        Icons.account_circle,
        size: 35,
      );
    }
  }

  Widget assetBuilder(context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const CircularProgressIndicator();
    } else if (snapshot.hasError) {
      return Text('Error: ${snapshot.error}');
    } else {
      return snapshot.data ?? const Text('Image not found');
    }
  }
  /*







   */
  /*Widget hasContent(items) {
    return items != null
        ? ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final subjectId = items.keys.elementAt(index);
              final subjectData = items[subjectId];

              // Add the subject ID to the list
              subjectIds.add(subjectId);

              return assignButton(
                context,
                id: subjectId,
                title: subjectData['subName'],
                start: subjectData['subTimeStart'],
                end: subjectData['subTimeEnd'],
                meet1: subjectData['meetingOne'],
                meet2: subjectData['meetingTwo'],
              );
            },
          )
        : const Center(
            child: Text("You currently have no subjects"),
          );
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(widget.details["subName"]!),
        actions: [
          iconContainer(GestureDetector(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const UserProfile()));
              },
              child: FutureBuilder<Widget>(
                future: setPfp(),
                builder: (context, snapshot) => assetBuilder(context, snapshot),
              ))),
          IconButton(
            onPressed: () {
              FirebaseAuth.instance.signOut();
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => const Login()));
            },
            icon: const Icon(Icons.logout_outlined),
          )
        ],
      ),
      body: ListView.builder(
          itemCount: actData.length + 1,
          itemBuilder: (context, index) {
            dynamic actId;
            dynamic actval;
            if (actData.keys.length > 0 && index > 0) {
              actId = actData.keys.elementAt(index - 1);
              actval = actData[actId];
            }

            return index == 0
                ? subjectInfo(
                    context,
                    title: widget.details['subName'],
                    desc: widget.details['subDesc'],
                    start: widget.details['subTimeStart'],
                    end: widget.details['subTimeEnd'],
                    meet1: widget.details['meetingOne'],
                    meet2: widget.details['meetingTwo'],
                  )
                : actval != null && actval['actType'] == 'assignment'
                    ? assignButton(
                        context,
                        id: actId,
                        title: actval["assignTitle"],
                        desc: actval["assignDesc"],
                        deadline:
                            actval["assignDlDate"] + actval["assignDlTime"],
                        type: actval["assignTitle"],
                      )
                    : actval != null && actval['actType'] == 'announcement'
                        ? announcement(context,
                            date: actval["announceDate"],
                            desc: actval["announceDesc"],
                            id: actId,
                            list: actval["attachList"] != null
                                ? actval["attachList"]
                                    .map((item) => item.toString())
                                    .toList()!
                                : [])
                        : const SizedBox.shrink();
          }),

      /*subjectInfo(
            context,
            title: widget.details['subName'],
            desc: widget.details['subDesc'],
            start: widget.details['subTimeStart'],
            end: widget.details['subTimeEnd'],
            meet1: widget.details['meetingOne'],
            meet2: widget.details['meetingTwo'],
          ),
          assignButton(
            context,
            title: widget.details['subName'],
            desc: widget.details['subDesc'],

          ),*/

      persistentFooterAlignment: AlignmentDirectional.center,
      persistentFooterButtons: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          buttonStyle(SizedBox(
            width: MediaQuery.of(context).size.width / 2.3,
            child: FilledButton(
                onPressed: () {},
                child: const Text(
                  "Start Session",
                  style: TextStyle(fontSize: 16),
                )),
          )),
          buttonStyle(SizedBox(
            width: MediaQuery.of(context).size.width / 2.3,
            child: FilledButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => CreateActivity(
                            subjectId: widget.id,
                            details: widget.details,
                          )));
                },
                child: const Text(
                  "Create..",
                  style: TextStyle(fontSize: 16),
                )),
          ))
        ])
      ],
    );
  }
}
