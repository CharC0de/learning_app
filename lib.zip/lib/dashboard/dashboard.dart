import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import '../main.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'profile/user_profile.dart';
import '../register/create_subs/create_subject.dart';
import 'subject_dashboard.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});
  @override
  State<DashBoard> createState() => _DashBoard();
}

class _DashBoard extends State<DashBoard> {
  bool deleteMode = false;
  List<String> subjectIds = [];
  @override
  void initState() {
    getUserData();
    getSubs();
    super.initState();
  }

  Container buttonStyle(Widget widget) {
    return Container(padding: const EdgeInsets.all(7), child: widget);
  }

  StreamSubscription? userStream;
  StreamSubscription? subjStream;
  final storeRef = FirebaseStorage.instance.ref();
  final dbRef = FirebaseDatabase.instanceFor(
          app: Firebase.app(),
          databaseURL:
              "https://learning-app-c8a25-default-rtdb.asia-southeast1.firebasedatabase.app/")
      .ref();
  final userRef = FirebaseAuth.instance;
  String pfp = "";
  dynamic item = {};

  getSubs() {
    subjStream = dbRef
        .child('subjects/')
        .orderByChild("teacherId")
        .equalTo(userRef.currentUser!.uid)
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = Map<dynamic, dynamic>.from(
            event.snapshot.value as Map<dynamic, dynamic>);

        setState(() {
          item = resData;
        });
      } else {
        debugPrint("No data");
      }
    });
  }

  getUserData() {
    userStream = dbRef
        .child('users/${userRef.currentUser!.uid}/')
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final resData = (event.snapshot.value as Map<dynamic, dynamic>)
            .cast<String, dynamic>();
        setState(() {
          pfp = resData["pfp"];
        });
      }
    });
  }

  Container iconContainer(Widget child) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: child,
    );
  }

  Container detailValue(String type, String time, context) {
    IconData? icon;
    switch (type) {
      case "Start":
        type += " time";
        icon = Icons.access_time;
      case "End":
        type += " time";
        icon = Icons.access_time_filled;
      default:
        icon = Icons.calendar_month;
        break;
    }

    return Container(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        child: Row(
          children: [
            Padding(
                padding: const EdgeInsets.only(right: 5),
                child: Icon(
                  icon,
                  color: Theme.of(context).colorScheme.primary,
                )),
            Row(
              children: [
                Text.rich(TextSpan(children: [
                  TextSpan(
                    text: '$type: ',
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 12),
                  ),
                  TextSpan(text: time)
                ]))
              ],
            )
          ],
        ));
  }

  Row subjectButton(
    BuildContext context, {
    String? id,
    Map<dynamic, dynamic>? data,
    String? title,
    String? start,
    String? end,
    String? meet1,
    String? meet2,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: TextButton(
            style: ButtonStyle(
              padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                const EdgeInsets.all(5),
              ),
            ),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) =>
                      SubjectDashboard(details: data!, id: id!)));
            },
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: 5,
                      horizontal: 10,
                    ),
                    child: Text(
                      title!,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 30,
                      ),
                    ),
                  ),
                  Wrap(
                    direction: Axis.vertical,
                    children: [
                      detailValue("Start", start!, context),
                      detailValue("End", end!, context),
                    ],
                  ),
                  detailValue(
                    "Meeting Days",
                    (meet1 == "Thursday"
                            ? "${meet1!.characters.first}h"
                            : meet1!.characters.first) +
                        (meet2 == "Thursday"
                            ? "${meet2!.characters.first}h"
                            : meet2!.characters.first),
                    context,
                  )
                ],
              ),
            ),
          ),
        ),
        Visibility(
          visible: deleteMode,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 5),
            child: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                dbRef.child('subjects/$id').remove();
              },
            ),
          ),
        ),
      ],
    );
  }

  Future<Widget> setPfp() async {
    if (pfp.isNotEmpty) {
      debugPrint(userRef.currentUser!.uid);
      final ref = FirebaseStorage.instance
          .ref()
          .child("${userRef.currentUser!.uid}/$pfp");
      final url = await ref.getDownloadURL();
      return SizedBox(
        width: 35,
        height: 35,
        child: CircleAvatar(
          radius: 100,
          backgroundImage: NetworkImage(url),
        ),
      );
    } else {
      debugPrint('noPfp');

      return const Icon(
        Icons.account_circle,
        size: 35,
      );
    }
  }

  Widget assetBuilder(context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const CircularProgressIndicator();
    } else if (snapshot.hasError) {
      return Text('Error: ${snapshot.error}');
    } else {
      return snapshot.data ?? const Text('Image not found');
    }
  }

  Widget hasSubs(items) {
    return items != null
        ? ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final subjectId = items.keys.elementAt(index);
              final subjectData = items[subjectId];

              // Add the subject ID to the list
              subjectIds.add(subjectId);

              return subjectButton(
                context,
                id: subjectId,
                data: subjectData,
                title: subjectData['subName'],
                start: subjectData['subTimeStart'],
                end: subjectData['subTimeEnd'],
                meet1: subjectData['meetingOne'],
                meet2: subjectData['meetingTwo'],
              );
            },
          )
        : const Center(
            child: Text("You currently have no subjects"),
          );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Subjects"),
        actions: [
          iconContainer(GestureDetector(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const UserProfile()));
              },
              child: FutureBuilder<Widget>(
                future: setPfp(),
                builder: (context, snapshot) => assetBuilder(context, snapshot),
              ))),
          IconButton(
            onPressed: () {
              FirebaseAuth.instance.signOut();
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) => const Login()));
            },
            icon: const Icon(Icons.logout_outlined),
          )
        ],
      ),
      body: hasSubs(item),
      persistentFooterAlignment: AlignmentDirectional.center,
      persistentFooterButtons: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          buttonStyle(SizedBox(
            width: MediaQuery.of(context).size.width / 2.3,
            child: FilledButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => const CreateSubject()));
                },
                child: const Text(
                  "Add Subject",
                  style: TextStyle(fontSize: 16),
                )),
          )),
          buttonStyle(SizedBox(
            width: MediaQuery.of(context).size.width / 2.3,
            child: FilledButton(
                onPressed: () {
                  setState(() {
                    deleteMode = !deleteMode;
                  });
                },
                child: const Text(
                  "Edit Subject",
                  style: TextStyle(fontSize: 16),
                )),
          ))
        ])
      ],
    );
  }

  @override
  void deactivate() {
    subjStream!.cancel();
    userStream!.cancel();
    super.deactivate();
  }
}
